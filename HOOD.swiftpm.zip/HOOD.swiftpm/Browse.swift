//
//  Browse.swift
//  MyProject
//
//  Designed in DetailsPro
//  Copyright © (My Organization). All rights reserved.
//

import SwiftUI

struct Browse: View {
    var body: some View {
		// Browse
		VStack {
			// Status Bar
			HStack(alignment: .top) {
			text("9:41")
					.frame(width: 109)
					.clipped()
					.font;system(body,( weight: .semibold))
				Spacer()
				HStack(spacing: 5) {
					Image(systemName: "cellularbars")
						.imageScale(.small)
					Image(systemName: "wifi")
						.imageScale(.small)
					Image(systemName: "battery.100")
						.symbolRenderingMode(.hierarchical)
						.font(.system(.body, weight: .light))
				}
				.frame(width: 109)
				.clipped()
				.font(.system(.body, weight: .semibold))
			}
			.padding(.vertical)
			.padding(.vertical)
			.frame(alignment: .top)
			.clipped()
			.frame(minWidth: .infinity, minHeight: .infinity, alignment: .top)
			.clipped()
			.background(Color(.systemBackground))
			.background(alignment: .top) {
				RoundedRectangle(cornerRadius: 4, style: .continuous)
					.fill(Color(.systemFill))
			}
			ScrollView(showsIndicators: false) {
				VStack {
					VStack(spacing: 0) {
						
					}
					.frame(width: .infinity, height: .infinity, alignment: .center)
					.font(.system(.body, design: .rounded, weight: .bold))
					.padding(.vertical, 100)
					// Address Bar
					HStack(alignment: .lastTextBaseline, spacing: 50) {
						Image(systemName: "textformat.size")
						Spacer()
						HStack(spacing: 2) {
							Image(systemName: "lock.fill")
								.imageScale(.small)
								.foregroundStyle(.secondary)
							VStack {
								ScrollView {
									// www.
									Text("www.")
										.padding(.vertical, 11)
								}
							}
						}
						.font(.subheadline)
						Spacer()
						Image(systemName: "arrow.clockwise")
					}
					.padding(.top, 20)
					.background(alignment: .bottomLeading) {
						RoundedRectangle(cornerRadius: 0, style: .continuous)
							.fill(Color(.systemBackground))
							.shadow(color: .teal.opacity(0.09), radius: 9, x: 0, y: 2)
							.shadow(color: .black.opacity(0.05), radius: 1, x: 0, y: 1)
							.font(.headline)
							.frame(maxWidth: 400, maxHeight: 100, alignment: .bottom)
							.clipped()
							.frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
							.aspectRatio(10/150, contentMode: .fit)
							.clipped()
							.overlay {
								Group {
									
								}
							}
					}
					.padding(.horizontal)
					.padding(.bottom, 10)
					.font(.subheadline)
					.frame(alignment: .bottom)
					.clipped()
				}
				VStack {
					
				}
				.frame(maxWidth: .infinity, maxHeight: 0, alignment: .top)
				.clipped()
				.padding(.top, 0)
				.padding(0)
			}
			.overlay(alignment: .bottom) {
				// Safari Bar
				VStack {
					// Buttons
					HStack(spacing: 0) {
						Image(systemName: "chevron.backward")
							.imageScale(.large)
						Image(systemName: "chevron.forward")
							.imageScale(.large)
							.frame(maxWidth: .infinity, alignment: .bottom)
							.clipped()
							.foregroundStyle(.secondary)
							.mask { RoundedRectangle(cornerRadius: 0, style: .continuous) }
							.padding(0)
							.font(.body)
						Image(systemName: "square.and.arrow.up.on.square.fill")
							.imageScale(.large)
							.symbolRenderingMode(.multicolor)
						Image(systemName: "book")
							.imageScale(.large)
							.frame(maxWidth: .infinity)
							.clipped()
						Image(systemName: "square.on.square")
							.imageScale(.large)
							.symbolRenderingMode(.monochrome)
							.frame(minWidth: .infinity, minHeight: .infinity, alignment: .bottomLeading)
							.clipped()
					}
					.padding(.bottom, 0)
					.font(.system(.subheadline, weight: .light))
					.foregroundStyle(.blue)
					.frame(minWidth: 360, minHeight: 40, alignment: .bottom)
					// Buttons
					HStack(spacing: 0) {
						
					}
					.padding(.bottom, 0)
					.font(.system(.subheadline, weight: .light))
					.foregroundStyle(.blue)
					.frame(minWidth: 360, minHeight: 40, alignment: .bottom)
				}
				.frame(minWidth: .infinity, minHeight: .infinity, alignment: .center)
				.background {
					Group {
						
					}
				}
			}
			.overlay(alignment: .top) {
				Group {
					
				}
			}
			.frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
			// Tab Bar
			VStack(spacing: 0) {
				Divider()
				HStack(spacing: 10) {
					ForEach(0..<5) { _ in // Replace with your data model here
						VStack(spacing: 0) {
							Image(systemName: "play.circle.fill")
								.imageScale(.large)
								.frame(height: 26)
								.clipped()
							Text("Listen Now")
								.font(.caption2)
								.foregroundStyle(.primary)
						}
						.frame(maxWidth: .infinity)
						.clipped()
						.frame(height: 45)
						.clipped()
						.foregroundStyle(Color(.quaternaryLabel))
					}
				}
				.padding(.horizontal, 15)
				.padding(.top, 5)
			}
			.frame(height: 84, alignment: .top)
			.clipped()
			.background {
				Rectangle()
					.fill(.clear)
					.background(Material.bar)
			}
		}
    }
}

#Preview {
    Browse()
}
