//
//  ListenNow.swift
//  MyProject
//
//  Designed in DetailsPro
//  Copyright © (My Organization). All rights reserved.
//

import SwiftUI

struct ListenNow: View {
    var body: some View {
		// Listen Now
		VStack {
			// Status Bar
			HStack {
				Text("9:41")
					.frame(width: 109)
					.(clipped)
					.font(system(.body, weight: .semibold))
				Spacer()
				HStack(spacing: 5) {
					Image(systemName: "cellularbars")
						.imageScale(.small)
					Image(systemName: "wifi")
						.imageScale(.small)
					Image(systemName: "battery.100")
						.symbolRenderingMode(.hierarchical)
						.font(.system(.body, weight: .light))
				}
				.frame(width: 109)
				.clipped()
				.font(.system(.body, weight: .semibold))
			}
			.padding(.vertical, 0)
			.padding()
			.frame(alignment: .top)
			.clipped()
			.frame(width: .infinity, height: .infinity, alignment: .bottom)
			.clipped()
			.background(Color(.systemBackground))
			.background {
				RoundedRectangle(cornerRadius: 4, style: .continuous)
					.fill(Color(.systemFill))
			}
			ScrollView {
				VStack(spacing: 0) {
					Image(uiImage: UIImage(named: "Image 2.jpg") ?? .init())
						.renderingMode(.original)
						.resizable()
						.aspectRatio(contentMode: .fit)
						.frame(minWidth: .infinity, minHeight: 300, alignment: .center)
						.mask { RoundedRectangle(cornerRadius: 10, style: .continuous) }
						.shadow(color: .black.opacity(0.2), radius: 8, x: 0, y: 4)
						.padding(0)
					// Buttons
					HStack(spacing: 20) {
						HStack(alignment: .bottom, spacing: 0) {
							Text("Play")
								.font(.system(.title2, design: .serif, weight: .bold))
								.padding(.trailing, 40)
							Image(systemName: "play.circle.fill")
								.imageScale(.large)
								.symbolRenderingMode(.monochrome)
								.font(.body)
								.fixedSize(horizontal: false, vertical: false)
								.frame(width: 60)
								.clipped()
							Image(systemName: "pause.circle.fill")
								.imageScale(.large)
								.symbolRenderingMode(.monochrome)
								.font(.body)
								.fixedSize(horizontal: false, vertical: false)
								.frame(width: 60)
								.clipped()
						}
						.foregroundStyle(.pink)
						.font(.system(.subheadline, weight: .semibold))
						.padding(.vertical, 12)
						.frame(maxWidth: .infinity, maxHeight: 50)
						.clipped()
						.background {
							RoundedRectangle(cornerRadius: 10, style: .continuous)
								.fill(Color(.quaternarySystemFill))
						}
						HStack(alignment: .bottom, spacing: 0) {
							Image(systemName: "repeat.circle.fill")
								.imageScale(.large)
								.symbolRenderingMode(.multicolor)
						}
						.foregroundStyle(.pink)
						.font(.system(.subheadline, weight: .semibold))
						.padding(.vertical, 12)
						.frame(minWidth: .infinity, minHeight: .infinity, alignment: .center)
						.clipped()
						.background {
							RoundedRectangle(cornerRadius: 10, style: .continuous)
								.fill(Color(.quaternarySystemFill))
						}
					}
					.padding()
					// Buttons
					HStack(spacing: 0) {
						HStack(spacing: 0) {
							Image(systemName: "15.arrow.trianglehead.counterclockwise")
								.imageScale(.large)
								.symbolRenderingMode(.multicolor)
								.font(.body)
								.fixedSize(horizontal: true, vertical: true)
								.frame(width: 60)
								.clipped()
							Image(systemName: "backward.end.fill")
								.imageScale(.large)
								.symbolRenderingMode(.multicolor)
								.font(.body)
								.fixedSize(horizontal: true, vertical: true)
								.frame(width: 60, alignment: .bottom)
								.clipped()
							Image(systemName: "backward.end.alt.fill")
								.imageScale(.large)
								.symbolRenderingMode(.multicolor)
								.font(.body)
								.fixedSize(horizontal: false, vertical: false)
								.frame(width: 60)
								.clipped()
							Image(systemName: "forward.end.alt.fill")
								.imageScale(.large)
								.symbolRenderingMode(.multicolor)
								.font(.body)
								.fixedSize(horizontal: false, vertical: false)
								.frame(width: 60)
								.clipped()
							Image(systemName: "forward.end.fill")
								.imageScale(.large)
								.symbolRenderingMode(.multicolor)
								.font(.body)
								.fixedSize(horizontal: false, vertical: true)
								.fixedSize(horizontal: true, vertical: false)
								.frame(width: 60, alignment: .bottom)
								.clipped()
								.padding(.trailing, 0)
								.font(.system(size: 13, weight: .regular, design: .default))
							Image(systemName: "15.arrow.trianglehead.counterclockwise")
								.imageScale(.large)
								.symbolRenderingMode(.multicolor)
								.font(.body)
								.fixedSize(horizontal: true, vertical: false)
								.frame(width: 60, alignment: .bottom)
								.clipped()
						}
						.foregroundStyle(.pink)
						.font(.system(.subheadline, weight: .semibold))
						.padding(0)
						.frame(minWidth: .infinity, minHeight: 70, alignment: .top)
						.clipped()
						.background(alignment: .trailing) {
							RoundedRectangle(cornerRadius: 10, style: .continuous)
								.fill(Color(.quaternarySystemFill))
						}
					}
					.padding(0)
					VStack(spacing: 0) {
						ForEach(0..<5) { _ in // Replace with your data model here
							Divider()
								.padding(.leading)
								.opacity(0.5)
							HStack(spacing: 0) {
								// Track #
								Text("1")
									.frame(width: 22, alignment: .leading)
									.clipped()
									.foregroundStyle(.secondary)
								Spacer()
								Image(systemName: "ellipsis")
							}
							.padding(.horizontal)
							.padding(.vertical, 14)
							.font(.subheadline)
							.padding(.leading, 8)
						}
						Divider()
							.padding(.leading)
							.opacity(0.5)
					}
					.frame(alignment: .top)
					.clipped()
				}
				.frame(maxWidth: .infinity)
				.clipped()
				.padding(.bottom, 98)
				.padding(.bottom, 150)
				.background {
					RoundedRectangle(cornerRadius: 0, style: .continuous)
						.fill(Color(.tertiaryLabel).opacity(0.81))
				}
			}
			.overlay(alignment: .top) {
				// Navigation Bar
				VStack(spacing: 1) {
					HStack(spacing: 0) {
						
					}
					.frame(height: 44)
					.clipped()
				}
				.frame(height: 60)
				.clipped()
				.background {
					Rectangle()
						.fill(.clear)
						.background(Material.bar)
						.foregroundStyle(.primary)
				}
				.foregroundStyle(.primary)
			}
			.overlay(alignment: .bottom) {
				// Tab Bar
				VStack(spacing: 0) {
					Divider()
					HStack(spacing: 10) {
						ForEach(0..<5) { _ in // Replace with your data model here
							VStack(spacing: 0) {
								Image(systemName: "play.circle.fill")
									.imageScale(.large)
									.frame(height: 26)
									.clipped()
								Text("Listen Now")
									.font(.caption2)
									.foregroundStyle(.primary)
							}
							.frame(maxWidth: .infinity)
							.clipped()
							.frame(height: 45)
							.clipped()
							.foregroundStyle(Color(.quaternaryLabel))
						}
					}
					.padding(.horizontal, 15)
					.padding(.top, 5)
				}
				.frame(height: 84, alignment: .top)
				.clipped()
				.background {
					Rectangle()
						.fill(.clear)
						.background(Material.bar)
				}
			}
		}
    }
}

#Preview {
    ListenNow()
}
